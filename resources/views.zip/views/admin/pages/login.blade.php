@extends('admin.template.master')

@section('content')
<div class="page-title">liveExperience Admin</div>
<div class="login-box">
	<form>
		<input type="text" name="username" placeholder="Username">
		<input type="text" name="password" placeholder="Password">
		<div class="submit">Log in</div>
	</form>
</div>
@stop