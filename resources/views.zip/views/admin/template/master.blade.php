<!DOCTYPE html>
<html>
<head>
	<!-- Title -->
	<title>Admin - Live Experience</title>

	<!-- Meta tags -->
	<meta charset="UTF-8">
	<meta name="description" content="Admin dashboard of live experience football application.">
	<meta name="keywords" content="live,, experience, live experience, admin, dashboard, admin dashboard">
	<meta property="og:title" content="Admin - Live Experience" />
	<meta property="og:description" content="Admin dashboard of live experience football application." />

	<!-- CSS -->
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:400,400i,700,700i" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="{{ asset('assets/css/normalize.css') }}">
	<link rel="stylesheet" type="text/css" href="{{ asset('assets/css/main.css') }}">
	@yield('extend_css')

</head>
<body>

	<!-- 1000px width container of the content -->
	<div class="main-container">
		@yield('content')
	</div>

	<!-- Scripts -->
	<script type="text/javascript" src="{{ asset('assets/javascript/jquery.min.js') }}"></script>
	<script type="text/javascript" src="{{ asset('assets/javascript/main.js') }}"></script>
	@yield('extend_javascript')

</body>
</html>